# Gerenciamento-de-Pokemon-em-js

Grupo: João Vitor Rodrigues Rocha, Lucas Fortunato Martins, Theo G. Gomide, Thayná de Rezende Euzébio

Tema: Sistema de gerenciamento de pokemon

Explicação: A ideia inicial é fazer um sistema de gerenciamento para times de pokemon, tendo até o momento 4 telas, Login, Save, "Deck" que é o time, e PC que é onde você pode escolher seus pokemons, dentro da tela de login tera um form com os dados de login e senha, após isso, a pessoa será direcionada para a tela de save, onde ela ira poder criar um save novo, ou excluir um que ja esteja ali, depois é hora de ver o time de pokemon, ali terão 6 pokemons diferentes e será possível editar as informações como por exemplo o nome do pokemon, excluir ele do  time e verificar seus status (talvez), na tela de pc é onde você pode levar um pokemon do seu "deck" para dentro do pc e trocar ele por outro (adicionar no "deck"). Até o momento essa é a ideia base.
